flowchart TD
A[Raw Text Input\n(files / paste / API)] --> B[Preprocessing\n(clean, tokenize, stopwords)]
B --> C[Feature Extraction]
C --> C1[TF-IDF Vectors]
C --> C2[Sentence Embeddings]
C1 --> D1[TF-IDF Sentence Scoring\n-> Extractive Summary]
C1 --> E1[TF-IDF Keyword Extraction]
C2 --> D2[Embedding-based\nRepresentative Sentence Selection]
D1 --> F[Summary Aggregation\n(reorder & finalize)]
D2 --> F
E1 --> G[Keyword Ranking\n(RAKE / YAKE / TF-IDF)]
F --> H[Evaluation\n(ROUGE, Embedding Sim)]
G --> H
H --> I[Output & Storage\n(CSV, JSON, Notebook cells)]
I --> J[Optional UI\n(Colab widgets / Streamlit)]